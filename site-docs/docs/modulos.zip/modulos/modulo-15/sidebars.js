module.exports = {
    tutorialSidebar: [
      {
        type: 'category',
        label: 'Módulo 15',
        position: 15,
        link: {
          type: 'generated-index',
          description: 'Modulo 15',
        },
        items: [
          'modulo-15'
        ],
      },
    ],
  };
  
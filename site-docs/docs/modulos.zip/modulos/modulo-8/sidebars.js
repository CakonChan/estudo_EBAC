module.exports = {
    tutorialSidebar: [
      {
        type: 'category',
        label: 'Módulo 8',
        position: 8,
        link: {
          type: 'generated-index',
          description: 'Modulo 8',
        },
        items: [
          'modulo-8'
        ],
      },
    ],
  };
  
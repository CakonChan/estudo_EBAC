module.exports = {
    tutorialSidebar: [
      {
        type: 'category',
        label: 'Módulo 13',
        position: 13,
        link: {
          type: 'generated-index',
          description: 'Modulo 13',
        },
        items: [
          'modulo-13'
        ],
      },
    ],
  };
  
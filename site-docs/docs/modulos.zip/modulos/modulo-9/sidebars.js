module.exports = {
    tutorialSidebar: [
      {
        type: 'category',
        label: 'Módulo 9',
        position: 9,
        link: {
          type: 'generated-index',
          description: 'Modulo 9',
        },
        items: [
          'modulo-9'
        ],
      },
    ],
  };
  